export const site = {
  name: "Mohammad Raka Saputra",
  shortName: "Raka",
  role: "Software Developer",
  tagline: "Building digital experiences for web and mobile.",
  description:
    "I build applications and digital solutions with a focus on user experience, functionality, and modern technology.",
  url: "https://rakasaputra.vercel.app", // TODO: ganti dengan URL vercel.app yang sebenarnya setelah deploy
  email: "mhrakaas@gmail.com",
  github: "https://github.com/rakasaputra23",
  linkedin: "https://www.linkedin.com/in/mohammad-raka-saputra-965652327/",
  cv: "/cv.pdf", // TODO: taruh file CV di public/cv.pdf
};

export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/projects", label: "Projects" },
  { href: "/experience", label: "Experience" },
  { href: "/contact", label: "Contact" },
] as const;
