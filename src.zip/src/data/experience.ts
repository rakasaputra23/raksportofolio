export type ExperienceItem = {
  period: string;
  role: string;
  org: string;
  type: "Internship" | "Organization";
  points: string[];
  tags?: string[];
};

// DRAF — silakan sesuaikan. Judul peran magang (role) adalah tebakan, mohon diganti
// jika jabatan resminya berbeda.
export const experience: ExperienceItem[] = [
  {
    period: "Jul 2025 — Dec 2025",
    role: "Software Developer Intern",
    org: "PT INKA Multi Solusi",
    type: "Internship",
    points: [
      "Developed Kasbon Online, a web application for managing cash advance and business trip requests.",
      "Built a Customer Complaint System using Laravel 13 and Filament.",
      "Worked with Laravel, PHP, and MySQL in a real company environment.",
    ],
    tags: ["Laravel", "PHP", "MySQL", "Filament"],
  },
  {
    period: "2024 — 2025",
    role: "Coordinator, Human Resources Division (PSDM)",
    org: "HIMATIF",
    type: "Organization",
    points: [
      "Coordinated the human resources division of the student association.",
      "Served as chairperson of the study program orientation event (masa pengenalan program studi).",
    ],
    tags: ["Leadership", "Event Management", "Teamwork"],
  },
];

export const education = {
  school: "Politeknik Negeri Madiun",
  program: "D3 Information Technology",
  note: "Diploma program in Information Technology (Teknologi Informasi).",
};
